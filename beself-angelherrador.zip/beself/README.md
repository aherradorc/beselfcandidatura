-------------------JUEGO DE AHORCADO-------------------
-----------------Ángel Herrador Colino-----------------

INSTALACIÓN

Para realizar la instalación del proyecto se necesita seguir estos pasos:
1. Copiar el contenido de la carpeta en localhost o en algún servidor.
2. Ejecutar el index.php --> localhost/index.php
			 --> miservidor/index.php
3. Jugar y disfrutar del juego. Hay 6 intentos por jugador.


EJECUCIÓN

Para poder jugar al ahorcado de superhéroes primero hay que especificar el número de jugadores. Una vez introducido el valor, hacer click en "Agregar Jugadores".
Se nos mostrará de forma dinámica inputs para poder especificar los nombres de los jugadores.
Una vez rellenado el/los input/s, hacer click en "Iniciar Juego".