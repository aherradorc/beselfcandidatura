<?php

class GameController {
    private $game;

    public function start() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $numPlayers = intval($_POST['numPlayers']);
            $players = [];
            for ($i = 0; $i < $numPlayers; $i++) {
                $players[] = new Player($_POST["player{$i}"]);
            }

            $this->game = new Game($players);
            $_SESSION['game'] = serialize($this->game);
            header('Location: ?action=play');
        } else {
            include 'views/start.php';
        }
    }

    public function play() {
        if (isset($_SESSION['game'])) {
            $this->game = unserialize($_SESSION['game']);

            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $letter = $_POST['letter'];
                $this->game->guessLetter($letter);
                $_SESSION['game'] = serialize($this->game);
            }

            if ($this->game->isGameOver() || $this->game->isWordGuessed()) {
                header('Location: ?action=result');
            } else {
                include 'views/game.php';
            }
        } else {
            header('Location: ?action=start');
        }
    }

    public function result() {
        if (isset($_SESSION['game'])) {
            $this->game = unserialize($_SESSION['game']);
            include 'views/result.php';
        } else {
            header('Location: ?action=start');
        }
    }
}
?>
