<?php
session_start();

require 'models/Game.php';
require 'models/Player.php';
require 'controllers/GameController.php';

$controller = new GameController();

$action = isset($_GET['action']) ? $_GET['action'] : 'start';

switch ($action) {
    case 'start':
        $controller->start();
        break;
    case 'play':
        $controller->play();
        break;
    case 'result':
        $controller->result();
        break;
    default:
        $controller->start();
        break;
}
?>
