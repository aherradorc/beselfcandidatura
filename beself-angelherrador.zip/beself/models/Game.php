<?php

class Game {
    private $players = []; //jugadores
    private $currentWord; //el superhéroe escogido de forma random del archivo txt
    private $maskedWord; //currentWord enmascarada
    private $attempts; //intento actual
    private $maxAttempts; //intentos máximos
    private $lettersGuessed = []; //array con letras acertadas
    private $lettersFailed = []; //array con letras falladas

    public function __construct($players, $maxAttempts = 6) {
        $this->players = $players;
        $this->maxAttempts = $maxAttempts;
        $this->attempts = 0;
        $this->chooseRandomWord();
        $this->maskWord();
    }

    private function chooseRandomWord() {
        //leer el archivo, separar los nombres por ";" y guardar el seleccionado en "currentWord"
        $file = 'data/datos.txt';
        if (file_exists($file)) {
            $content = file_get_contents($file);
            $words = explode(';', $content);
            $this->currentWord = trim($words[array_rand($words)]);
        } else {
            throw new Exception("El archivo no existe.");
        }
    }

    private function maskWord() {
        //enmascarar "currentWord"
        $this->maskedWord = '';
        for ($i = 0; $i < strlen($this->currentWord); $i++) {
            if ($this->currentWord[$i] == ' ') {
                $this->maskedWord .= ' ';
            } elseif ($this->currentWord[$i] == '-') {
                $this->maskedWord .= '-';
            } else {
                $this->maskedWord .= '_';
            }
        }
    }

    public function guessLetter($letter) {
        if (in_array($letter, $this->lettersGuessed)) {
            return false;
        }

        $this->lettersGuessed[] = $letter;
        $found = false;

        for ($i = 0; $i < strlen($this->currentWord); $i++) {
            if (strtolower($this->currentWord[$i]) == strtolower($letter)) {
                $this->maskedWord[$i] = $this->currentWord[$i];
                $found = true;
            }
        }

        if (!$found) {
            //si el boolean es falso, aumentar el valor de "attempts" y guardar la letra seleccionada en array de "letterFailed"
            $this->attempts++;
            $this->lettersFailed[] = $letter;
        }

        return $found;
    }

    //funciones para obtener valor de las variables
    public function getMaskedWord() {
        return $this->maskedWord;
    }

    public function getAttempts() {
        return $this->attempts;
    }

    public function getMaxAttempts() {
        return $this->maxAttempts;
    }

    public function isGameOver() {
        return $this->attempts >= $this->maxAttempts;
    }

    public function isWordGuessed() {
        return strpos($this->maskedWord, '_') === false;
    }

    public function getCurrentWord() {
        return $this->currentWord;
    }

    public function getGuessedLetters() {
        $correctLetters = [];
        foreach ($this->lettersGuessed as $letter) {
            if (stripos($this->currentWord, $letter) !== false) {
                if (!in_array($letter, $correctLetters)) {
                    $correctLetters[] = $letter;
                }
            }
        }
        return $correctLetters;
    }

    public function getFailedLetters() {
        $failedLetters = [];
        foreach ($this->lettersFailed as $letter) {
            if (!in_array($letter, $failedLetters)) {
                $failedLetters[] = $letter;
            }
        }
        return $failedLetters;
    }

    public function changeImg($attempt) {
        //para modificar la imagen con el valor de intentos actuales
        $img = './img/hangman-'.$attempt.'.svg';
        return $img;
    }
}
?>
