<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Inicio del Juego</title>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <!--Bootstrap-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    </head>
    <body>
        <div class="contenedor">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <h1 class="text-center">Juego de Ahorcado</h1>
                        <form method="post" action="">
                            <div class="form-group">
                                <label for="numPlayers">Número de jugadores:</label>
                                <input type="number" class="form-control" id="numPlayers" name="numPlayers" aria-describedby="numPlayersSmall" required>
                                <small id="numPlayersSmall" class="form-text text-muted">Introduce la cantidad de jugadores</small>
                            </div>
                            <div class="form-group">
                                <div id="players"></div>
                            </div>
                            <br>
                            <button type="button" onclick="addPlayers()" class="btn btn-success">Agregar Jugadores</button>
                            <button type="submit" class="btn btn-primary">Iniciar Juego</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script>
            //funcion para añadir input de los nombres del jugador en funcion del número de jugadores seleccionados:
            function addPlayers() {
                const numPlayers = document.getElementById('numPlayers').value;
                const playersDiv = document.getElementById('players');
                playersDiv.innerHTML = '';

                for (let i = 0; i < numPlayers; i++) {
                    playersDiv.innerHTML += `<label for="player${i}">Jugador ${i + 1}:</label><input type="text" id="player${i}" class="form-control" name="player${i}" required>`;
                }
            }
        </script>
    </body>
</html>
