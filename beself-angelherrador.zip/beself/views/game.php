<!DOCTYPE html>
<html lang="es">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Juego de Ahorcado</title>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <!--Bootstrap-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    </head>
    <body>
        <?php
        //Obtenemos las letras acertadas y las falladas:
        $letrasAcertadas = $this->game->getGuessedLetters();
        $letrasFailed = $this->game->getFailedLetters();
        ?>
        <div class="contenedor">
            <div class="container text-center">
                <div class="row">
                    <div class="col">
                        <img src="<?= $this->game->changeImg($this->game->getAttempts()) ?>" alt="#">
                    </div>
                    <div class="col">
                        <form method="post" action="" id="formulario">
                            <h1>Juego de Ahorcado</h1>
                            <input type="hidden" name="letter" id="letterInput">
                            <div class="letras"></div>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <p style="margin-top: 1rem;">Intentos: <?= $this->game->getAttempts() ?> / <?= $this->game->getMaxAttempts() ?></p>
                        <h1><span id="maskedWord"><?= $this->game->getMaskedWord() ?></h1>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    </body>
    <script type="text/javascript">
        //obtener las letras que se van diciendo para poder deshabilitar las letras button
    	const letrasAcertadas = <?= json_encode(array_map('strtolower', $letrasAcertadas)) ?>;
        const letrasFalladas = <?= json_encode(array_map('strtolower', $letrasFailed)) ?>;

    	const añadirListener = (button, clickedLetter) => {
    		const letra = button.innerText;
    		document.getElementById('letterInput').value = letra;
    		button.disabled = true;
    		document.getElementById('formulario').submit();
    	}

    	for (var i = 97; i <= 122; i++) {
            //añadimos con el js las letras y le añadimos un listener para que envie la letra seleccionada al modelo
    		const button = document.createElement("button");
    		const letter = String.fromCharCode(i);
    		button.innerText = letter;

    		if (letrasAcertadas.includes(letter) || letrasFalladas.includes(letter)) {
    			button.disabled = true;
    		}
    		const letras = document.querySelector(".letras");
    		letras.appendChild(button);
    		button.addEventListener("click", (e) => añadirListener(e.target, String.fromCharCode(i)));
    	}
    </script>
</html>