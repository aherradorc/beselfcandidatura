<!DOCTYPE html>
<html lang="es">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
	    <title>Resultado del Juego</title>
	    <link rel="stylesheet" type="text/css" href="./css/style.css">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <!--Bootstrap-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	</head>
	<body>
		<div class="contenedor">
			<div class="container">
				<div class="row">
					<div class="col">
						<h1 class="text-center">Resultado del Juego</h1>
						<?php if ($this->game->isWordGuessed()): ?>
				        <p>¡Felicidades! Has adivinado la palabra: <b><?= $this->game->getCurrentWord() ?></b></p>
					    <?php else: ?>
					        <p>Lo siento, has perdido. La palabra era: <b><?= $this->game->getCurrentWord() ?></b></p>
					    <?php endif; ?>
					    <a href="?action=start">Jugar de nuevo</a>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
